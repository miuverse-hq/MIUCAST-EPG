const fs = require('fs');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const { ChannelWorker } = require('./worker');

const app = express();
const PORT = Number(process.env.PORT || 2121);
const ADMIN_PORT = Number(process.env.ADMIN_PORT || 8080);
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || `http://127.0.0.1:${PORT}`;
const HLS_ROOT = process.env.HLS_ROOT || path.join(process.cwd(), 'storage', 'hls');
fs.mkdirSync(HLS_ROOT, { recursive: true });

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('combined'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(rateLimit({ windowMs: 60_000, max: 240, standardHeaders: true, legacyHeaders: false }));

function slugify(input) {
  return input.toString().trim().toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64) || 'channel';
}
function validSource(url) {
  try { const u = new URL(url); return ['http:', 'https:'].includes(u.protocol); } catch (_) { return false; }
}
function publicChannel(channel) {
  return { ...channel, clearkey_key: undefined, clearkey_kid: undefined };
}
function rowState(channel) {
  const w = workers.get(channel.id);
  return w ? w.state() : { status: channel.enabled ? 'not-started' : 'disabled', session: null };
}

const workers = new Map();
function startWorker(channel) {
  if (!channel.enabled) return;
  if (!workers.has(channel.id)) workers.set(channel.id, new ChannelWorker(channel));
  workers.get(channel.id).start();
}
function stopWorker(channelId) {
  const w = workers.get(channelId);
  if (w) w.stop();
}

for (const ch of db.prepare('SELECT * FROM channels WHERE enabled=1').all()) setTimeout(() => startWorker(ch), 500);

app.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM channels ORDER BY id DESC').all().map(ch => ({ ...publicChannel(ch), state: rowState(ch) }));
  res.render('index', { rows, publicBaseUrl: PUBLIC_BASE_URL });
});

app.get('/channels/new', (req, res) => res.render('edit', { channel: null, error: null }));
app.get('/channels/:id/edit', (req, res) => {
  const channel = db.prepare('SELECT * FROM channels WHERE id=?').get(req.params.id);
  if (!channel) return res.status(404).send('Not found');
  res.render('edit', { channel: publicChannel(channel), error: null });
});

app.post('/channels', (req, res) => {
  const name = String(req.body.name || '').trim();
  const sourceUrl = String(req.body.source_url || '').trim();
  const enabled = req.body.enabled === '1' ? 1 : 0;
  const clearkey_kid = String(req.body.clearkey_kid || '').trim() || null;
  const clearkey_key = String(req.body.clearkey_key || '').trim() || null;
  if (!name || !validSource(sourceUrl)) return res.status(400).render('edit', { channel: req.body, error: 'Name and a valid HTTP(S) MPD source URL are required.' });
  let slug = slugify(req.body.slug || name);
  try {
    const exists = db.prepare('SELECT id FROM channels WHERE slug=? OR name=?').get(slug, name);
    if (exists) slug = `${slug}-${Date.now().toString().slice(-5)}`;
    const info = db.prepare(`INSERT INTO channels(name,slug,source_url,clearkey_kid,clearkey_key,enabled,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)`).run(name, slug, sourceUrl, clearkey_kid, clearkey_key, enabled);
    const channel = db.prepare('SELECT * FROM channels WHERE id=?').get(info.lastInsertRowid);
    if (enabled) startWorker(channel);
    res.redirect('/');
  } catch (e) {
    res.status(400).render('edit', { channel: req.body, error: e.message });
  }
});

app.post('/channels/:id', (req, res) => {
  const id = Number(req.params.id);
  const current = db.prepare('SELECT * FROM channels WHERE id=?').get(id);
  if (!current) return res.status(404).send('Not found');
  const name = String(req.body.name || '').trim();
  const slug = slugify(req.body.slug || name);
  const sourceUrl = String(req.body.source_url || '').trim();
  const enabled = req.body.enabled === '1' ? 1 : 0;
  if (!name || !validSource(sourceUrl)) return res.status(400).render('edit', { channel: { ...current, ...req.body }, error: 'Name and a valid HTTP(S) MPD source URL are required.' });
  try {
    db.prepare(`UPDATE channels SET name=?,slug=?,source_url=?,clearkey_kid=?,clearkey_key=?,enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
      .run(name, slug, sourceUrl, req.body.clearkey_kid || null, req.body.clearkey_key || null, enabled, id);
    stopWorker(id);
    workers.delete(id);
    const updated = db.prepare('SELECT * FROM channels WHERE id=?').get(id);
    if (enabled) setTimeout(() => startWorker(updated), 300);
    res.redirect('/');
  } catch (e) {
    res.status(400).render('edit', { channel: { ...current, ...req.body }, error: e.message });
  }
});

app.post('/channels/:id/delete', (req, res) => {
  const id = Number(req.params.id);
  stopWorker(id); workers.delete(id);
  db.prepare('DELETE FROM channels WHERE id=?').run(id);
  res.redirect('/');
});

app.post('/channels/:id/toggle', (req, res) => {
  const id = Number(req.params.id);
  const current = db.prepare('SELECT * FROM channels WHERE id=?').get(id);
  if (!current) return res.status(404).json({ error: 'Not found' });
  const enabled = current.enabled ? 0 : 1;
  db.prepare('UPDATE channels SET enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(enabled, id);
  if (enabled) startWorker(db.prepare('SELECT * FROM channels WHERE id=?').get(id)); else stopWorker(id);
  res.redirect('/');
});

function findWorker(slug, session) {
  for (const worker of workers.values()) {
    if (worker.channel.slug === slug && worker.session === session) return worker;
  }
  return null;
}

async function sendProxyResponse(res, body, contentType = 'application/vnd.apple.mpegurl') {
  res.set({ 'Content-Type': contentType, 'Cache-Control': 'no-store, no-cache, must-revalidate', 'Access-Control-Allow-Origin': '*' });
  res.send(body);
}

app.get('/watch/:slug/:session.m3u8', async (req, res) => {
  const worker = findWorker(req.params.slug, req.params.session);
  if (!worker) return res.status(404).send('Unknown or expired MUICAST session');
  try {
    const profile = String(req.query.profile || '').toLowerCase() || (req.header('x-muicast-profile') || '').toLowerCase();
    const body = await worker.handleMaster(profile === '720' ? '720' : '');
    await sendProxyResponse(res, body);
  } catch (e) {
    worker.error = e.message;
    res.status(502).json({ error: 'Upstream/MediaFlow error', message: e.message });
  }
});

app.get('/watch/:slug/:session/:resource', async (req, res) => {
  const worker = findWorker(req.params.slug, req.params.session);
  if (!worker) return res.status(404).send('Unknown or expired MUICAST session');
  try {
    const result = await worker.handleResource(req.params.resource);
    const type = result.contentType || 'application/octet-stream';
    await sendProxyResponse(res, result.body, type);
  } catch (e) {
    res.status(502).json({ error: 'Upstream/MediaFlow resource error', message: e.message });
  }
});

app.get('/api/channels', (req, res) => {
  const rows = db.prepare('SELECT * FROM channels ORDER BY id DESC').all().map(ch => {
    const w = workers.get(ch.id);
    return { ...publicChannel(ch), state: rowState(ch), output: w ? w.outputUrl(PUBLIC_BASE_URL) : null };
  });
  res.json(rows);
});

app.get('/api/channels/:id/status', (req, res) => {
  const ch = db.prepare('SELECT * FROM channels WHERE id=?').get(req.params.id);
  if (!ch) return res.status(404).json({ error: 'Not found' });
  const w = workers.get(ch.id);
  res.json({ channel: publicChannel(ch), state: w ? w.state() : null, output: w ? w.outputUrl(PUBLIC_BASE_URL) : null });
});

app.get('/health', (req, res) => res.json({ ok: true, channels: workers.size, uptime: process.uptime() }));
app.listen(ADMIN_PORT, () => console.log(`MUICAST admin UI: http://0.0.0.0:${ADMIN_PORT}`));
app.listen(PORT, () => console.log(`MUICAST HLS gateway: http://0.0.0.0:${PORT}/watch/...`));

function shutdown() { for (const w of workers.values()) w.stop(); process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
