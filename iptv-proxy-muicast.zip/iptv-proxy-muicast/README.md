# IPTV PROXY by MUICAST v1.2

MUICAST is a Dockerized IPTV gateway for authorized MPEG-DASH/MPD streams. MediaFlow Proxy is used as the upstream media/DRM gateway for ClearKey MPD -> HLS, while the MUICAST Node.js layer provides channel CRUD, 5-digit sessions, pre-warming, device profiles, and a stable public HLS URL.

## Architecture

Client -> `:2121/watch/<channel>/<5-digit-session>.m3u8` -> MUICAST HLS Gateway -> MediaFlow Proxy -> source MPD/ClearKey

MediaFlow handles ClearKey DASH -> HLS and live buffering; MUICAST filters video renditions and rewrites HLS resource URLs so the MediaFlow password never appears in the public M3U8.

## Video policy

Only source representations at **720p** and **1080p** are exposed. 360p/480p are dropped. `?profile=720` (or `X-MUICAST-Profile: 720`) exposes only 720p for conservative/legacy player compatibility.

## Audio policy

All audio renditions from the MediaFlow HLS output are preserved. MUICAST detects `audio th`, `tha`, `Thai`, or `ไทย` in the audio `NAME`, `LANGUAGE`, or `TITLE` attributes and marks that track `DEFAULT=YES`; other tracks remain available.

## Live-edge / pre-warm

Each enabled channel continuously refreshes the MediaFlow MPD->HLS master approximately every 2 seconds. MediaFlow's live start offset is set to `-18` seconds by default, which gives a ready-made playback headroom rather than making the client wait for the original 18-45 second source startup.

## ClearKey

The channel editor accepts the authorized KID and Key. They are sent only from the internal MUICAST container to MediaFlow and are never returned by `/api/channels` or `/api/channels/:id/status`.

## Deploy on Ubuntu 20.04 / Docker Compose 1.25

1. Copy `.env.example` to `.env` and set `MEDIAFLOW_API_PASSWORD`.
2. Set `PUBLIC_BASE_URL` to the real server address.
3. Run `docker-compose up -d --build`.
4. Admin UI: `http://SERVER:8080`
5. HLS output: `http://SERVER:2121/watch/CHANNEL/SESSION.m3u8`

This stack uses Compose file syntax `version: '2.2'`.

## Notes

Use only streams and ClearKey material you are authorized to access and process. MediaFlow Proxy is MIT licensed and documents ClearKey DASH -> HLS support and live pre-buffer features: https://github.com/mhdzumair/mediaflow-proxy
