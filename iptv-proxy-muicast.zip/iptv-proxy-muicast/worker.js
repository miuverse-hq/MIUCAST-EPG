const crypto = require('crypto');

const MEDIAFLOW_URL = (process.env.MEDIAFLOW_URL || 'http://mediaflow:8888').replace(/\/$/, '');
const MEDIAFLOW_PASSWORD = process.env.MEDIAFLOW_API_PASSWORD || '';
const START_OFFSET = Number(process.env.MEDIAFLOW_START_OFFSET || -18);
const PREWARM_INTERVAL_MS = Number(process.env.PREWARM_INTERVAL_MS || 2000);
const FETCH_TIMEOUT_MS = Number(process.env.MEDIAFLOW_FETCH_TIMEOUT_MS || 20000);
const MAX_VARIANTS = Number(process.env.MAX_VARIANTS || 2);

function random5() {
  return String(Math.floor(10000 + Math.random() * 90000));
}

function token() {
  return crypto.randomBytes(12).toString('base64url');
}

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function thaiScore(fields) {
  const text = fields.filter(Boolean).join(' ').toLowerCase();
  let score = 0;
  if (/\baudio\s*th\b/.test(text)) score += 100;
  if (/\btha\b/.test(text)) score += 80;
  if (/thai|ไทย/.test(text)) score += 60;
  return score;
}

function attrValue(line, key) {
  const m = line.match(new RegExp(`${key}=((?:"[^"]*")|(?:[^,]*))`));
  return m ? m[1].replace(/^"|"$/g, '') : '';
}

function replaceAttr(line, key, value) {
  const re = new RegExp(`${key}=("[^"]*"|[^,]*)`);
  const rendered = /[,\s]/.test(String(value)) ? `"${value.replace(/"/g, '')}"` : value;
  if (re.test(line)) return line.replace(re, `${key}=${rendered}`);
  return `${line},${key}=${rendered}`;
}

class ChannelWorker {
  constructor(channel) {
    this.channel = channel;
    this.session = channel.session || random5();
    this.status = 'idle';
    this.error = null;
    this.startedAt = null;
    this.lastManifestAt = null;
    this.lastUpstreamStatus = null;
    this.lastExit = null;
    this.stopping = false;
    this.timer = null;
    this.resourceMap = new Map();
    this.sequence = 0;
  }

  outputUrl(baseUrl) {
    return `${baseUrl.replace(/\/$/, '')}/watch/${this.channel.slug}/${this.session}.m3u8`;
  }

  mediaflowUrl(extra = {}) {
    const url = new URL(`${MEDIAFLOW_URL}/proxy/mpd/manifest.m3u8`);
    url.searchParams.set('d', this.channel.source_url);
    url.searchParams.set('api_password', MEDIAFLOW_PASSWORD);
    url.searchParams.set('start_offset', String(extra.start_offset ?? START_OFFSET));
    if (this.channel.clearkey_kid) url.searchParams.set('key_id', this.channel.clearkey_kid);
    if (this.channel.clearkey_key) url.searchParams.set('key', this.channel.clearkey_key);
    return url.toString();
  }

  async fetch(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/vnd.apple.mpegurl, application/x-mpegURL, */*' }
      });
      this.lastUpstreamStatus = response.status;
      const buffer = Buffer.from(await response.arrayBuffer());
      if (!response.ok) {
        throw new Error(`MediaFlow HTTP ${response.status}: ${buffer.toString('utf8').slice(0, 300)}`);
      }
      return {
        body: buffer,
        contentType: response.headers.get('content-type') || ''
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  async fetchText(url) {
    const result = await this.fetch(url);
    return result.body.toString('utf8');
  }

  register(upstreamUrl) {
    const id = `${Date.now().toString(36)}-${(++this.sequence).toString(36)}-${token()}`;
    this.resourceMap.set(id, { url: upstreamUrl, touchedAt: Date.now() });
    if (this.resourceMap.size > 4000) {
      const entries = [...this.resourceMap.entries()].sort((a, b) => a[1].touchedAt - b[1].touchedAt);
      for (let i = 0; i < 500; i++) this.resourceMap.delete(entries[i][0]);
    }
    return id;
  }

  cleanupResource(id) {
    const item = this.resourceMap.get(id);
    if (item) item.touchedAt = Date.now();
    return item;
  }

  filterMaster(playlist, profile, baseUrl) {
    const lines = playlist.split(/\r?\n/);
    const media = [];
    for (const line of lines) {
      if (line.startsWith('#EXT-X-MEDIA:')) media.push(line);
    }

    const thaiByGroup = new Map();
    for (const line of media) {
      if (attrValue(line, 'TYPE') !== 'AUDIO') continue;
      const group = attrValue(line, 'GROUP-ID');
      const fields = [attrValue(line, 'NAME'), attrValue(line, 'LANGUAGE'), attrValue(line, 'TITLE')];
      const score = thaiScore(fields);
      if (score > (thaiByGroup.get(group)?.score || -1)) thaiByGroup.set(group, { line, score });
    }

    const out = [];
    const keptVariantIndexes = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];
      if (line.startsWith('#EXT-X-STREAM-INF:')) {
        const next = lines[i + 1] || '';
        const resolution = attrValue(line, 'RESOLUTION');
        const height = Number((resolution.match(/x(\d+)/i) || [])[1] || 0);
        const allowed = height === 720 || height === 1080;
        const safeProfile = String(profile || '').toLowerCase() === '720';
        const finalAllowed = allowed && (!safeProfile || height <= 720);
        if (finalAllowed && keptVariantIndexes.length < MAX_VARIANTS) {
          const uri = isHttpUrl(next) ? next : new URL(next, baseUrl).toString();
          out.push(line);
          out.push(this.register(uri));
          keptVariantIndexes.push({ height, uri: out[out.length - 1] });
        }
        i += 2;
        continue;
      }
      if (line.startsWith('#EXT-X-MEDIA:')) {
        if (attrValue(line, 'TYPE') !== 'AUDIO') {
          out.push(line);
        } else {
          const group = attrValue(line, 'GROUP-ID');
          const thai = thaiByGroup.get(group);
          const isThai = thai && thai.line === line;
          let rewritten = line;
          rewritten = replaceAttr(rewritten, 'DEFAULT', isThai ? 'YES' : 'NO');
          const uri = attrValue(rewritten, 'URI');
          if (uri) rewritten = rewritten.replace(`URI="${uri}"`, `URI="${this.register(new URL(uri, baseUrl).toString())}"`);
          out.push(rewritten);
        }
        i += 1;
        continue;
      }
      out.push(line);
      i += 1;
    }

    if (!keptVariantIndexes.length) {
      throw new Error('No supported 720p/1080p representation found in MediaFlow HLS output.');
    }
    return out.join('\n');
  }

  rewriteMediaPlaylist(playlist, baseUrl) {
    const lines = playlist.split(/\r?\n/);
    return lines.map(line => {
      if (!line || line.startsWith('#')) {
        if (line.includes('URI="')) {
          return line.replace(/URI="([^"]+)"/g, (_m, uri) => {
            const absolute = new URL(uri, baseUrl).toString();
            return `URI="${this.register(absolute)}"`;
          });
        }
        return line;
      }
      const absolute = new URL(line.trim(), baseUrl).toString();
      return this.register(absolute);
    }).join('\n');
  }

  async handleMaster(profile) {
    this.status = 'running';
    const upstreamUrl = this.mediaflowUrl();
    const source = await this.fetchText(upstreamUrl);
    this.lastManifestAt = new Date().toISOString();
    return this.filterMaster(source, profile, upstreamUrl);
  }

  async handleResource(id) {
    const item = this.cleanupResource(id);
    if (!item) throw new Error('Unknown or expired stream resource');
    const result = await this.fetch(item.url);
    const text = result.body.toString('utf8');
    const looksPlaylist = text.includes('#EXTM3U');
    return {
      body: looksPlaylist ? Buffer.from(this.rewriteMediaPlaylist(text, item.url), 'utf8') : result.body,
      contentType: looksPlaylist ? 'application/vnd.apple.mpegurl' : (result.contentType || 'video/iso.segment')
    };
  }

  prewarm() {
    if (this.timer || this.stopping) return;
    this.status = 'starting';
    this.error = null;
    this.startedAt = new Date().toISOString();
    const tick = async () => {
      if (this.stopping) return;
      try {
        await this.handleMaster('');
        this.status = 'running';
        this.error = null;
      } catch (e) {
        this.status = 'error';
        this.error = e.message;
      } finally {
        if (!this.stopping) this.timer = setTimeout(tick, PREWARM_INTERVAL_MS);
      }
    };
    tick();
  }

  start() {
    if (!this.channel.enabled) return;
    this.stopping = false;
    this.prewarm();
  }

  stop() {
    this.stopping = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.status = 'stopped';
    this.resourceMap.clear();
  }

  state() {
    return {
      id: this.channel.id,
      name: this.channel.name,
      slug: this.channel.slug,
      session: this.session,
      status: this.status,
      engine: 'MediaFlow Proxy + MUICAST HLS Gateway',
      startedAt: this.startedAt,
      lastManifestAt: this.lastManifestAt,
      mediaflowStatus: this.lastUpstreamStatus,
      resourceCache: this.resourceMap.size,
      error: this.error,
      lastExit: this.lastExit
    };
  }
}

module.exports = { ChannelWorker, random5, MEDIAFLOW_URL };
