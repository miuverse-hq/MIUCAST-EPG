# MPD PROXY by MIUCAST

Production-oriented starter overlay around MediaFlow Proxy:

- PHP 8.3 + Bootstrap 5.3.8 UI
- PostgreSQL 16
- Docker Compose 3.8 syntax (works with Docker Compose v1.25)
- Port 2121
- 4-digit admin passcode, default `1997`
- MPD → HLS/M3U8 through MediaFlow
- SHA-1 first 5 chars as stream identifier
- 4-char session URL
- THA audio policy field
- 720p policy for a declared `l3` client profile
- Optional authorized ClearKey passthrough to MediaFlow

## Start

```bash
cp .env.example .env
nano .env
docker-compose up -d --build
docker-compose ps
```

Open:

`http://SERVER_IP:2121`

## Important

The L1/L2/L3 field is intentionally a policy/profile mechanism, not a claim that a normal HTTP client can prove its Widevine security level. For a real Android app, send a trusted/signed capability assertion from a client you control.

The ClearKey fields are intended only for content and keys you are authorized to decrypt. This project does not implement Widevine CDM/key extraction or DRM bypass.

## Current MVP limitation

The first MVP proxies the MPD master manifest through PHP and rewrites URI lines. For a full production build, nested media playlists and segment requests should be routed through a dedicated media session controller instead of treating every URI as a master manifest. That controller is the next hardening step.
