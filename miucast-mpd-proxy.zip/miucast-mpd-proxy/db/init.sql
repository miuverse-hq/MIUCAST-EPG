CREATE TABLE IF NOT EXISTS streams (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    name_hash CHAR(5) NOT NULL UNIQUE,
    mpd_url TEXT NOT NULL,
    audio_default VARCHAR(16) NOT NULL DEFAULT 'auto',
    max_policy VARCHAR(16) NOT NULL DEFAULT 'auto',
    key_id TEXT NULL,
    key_value TEXT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stream_sessions (
    id BIGSERIAL PRIMARY KEY,
    stream_id BIGINT NOT NULL REFERENCES streams(id) ON DELETE CASCADE,
    session_code CHAR(4) NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_stream_sessions_lookup
ON stream_sessions(stream_id, session_code, expires_at);
