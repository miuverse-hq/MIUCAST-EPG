<?php
declare(strict_types=1);

function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $dsn='pgsql:host='.getenv('DB_HOST').';port='.getenv('DB_PORT').';dbname='.getenv('DB_NAME');
        $pdo=new PDO($dsn,getenv('DB_USER'),getenv('DB_PASSWORD'),[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
        ]);
    }
    return $pdo;
}
function random_session_code(): string {
    $alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out='';
    for($i=0;$i<4;$i++) $out.=$alphabet[random_int(0,strlen($alphabet)-1)];
    return $out;
}
function rewrite_mediaflow_manifest(string $body,string $mpd,string $hash,string $session): string {
    $lines=preg_split("/\r\n|\n|\r/",$body);
    $out=[];
    foreach($lines as $line){
        $trim=trim($line);
        if($trim==='' || str_starts_with($trim,'#')){
            if(str_starts_with($trim,'#EXT-X-MEDIA:') && preg_match('/URI="([^"]+)"/',$line,$mm)){
                $u=$mm[1];
                $line=str_replace($u, '/live/'.rawurlencode($hash).'/'.rawurlencode($session).'.m3u8?sub='.rawurlencode($u), $line);
            }
            $out[]=$line; continue;
        }
        $out[]='/live/'.rawurlencode($hash).'/'.rawurlencode($session).'.m3u8?sub='.rawurlencode($trim);
    }
    return implode("\n",$out);
}
