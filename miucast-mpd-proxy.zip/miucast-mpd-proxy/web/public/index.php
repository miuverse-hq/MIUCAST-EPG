<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../src/bootstrap.php';

if (!isset($_SESSION['auth'])) {
    header('Location: /login.php');
    exit;
}

$streams = db()->query("SELECT * FROM streams ORDER BY id DESC")->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MIUCAST — MPD PROXY</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#fff}.btn-miu{background:#dc2626;color:#fff;border:0}.btn-miu:hover{background:#b91c1c;color:#fff}
.card{border-radius:16px}.brand{font-weight:800;letter-spacing:.08em}
</style>
</head>
<body>
<nav class="navbar border-bottom bg-white">
<div class="container"><span class="navbar-brand brand">MIUCAST / MPD PROXY</span><a href="/logout.php" class="btn btn-outline-dark btn-sm">Logout</a></div>
</nav>
<main class="container py-4">
<div class="d-flex justify-content-between align-items-center mb-4">
  <div><h2 class="mb-1">Streams</h2><div class="text-secondary">MPD → M3U8 gateway</div></div>
  <a href="/stream.php" class="btn btn-miu">+ Add Stream</a>
</div>
<div class="card shadow-sm"><div class="table-responsive"><table class="table align-middle mb-0">
<thead><tr><th>Name</th><th>Policy</th><th>Audio</th><th>Status</th><th>Output</th></tr></thead>
<tbody>
<?php foreach ($streams as $s): ?>
<tr>
<td><strong><?=htmlspecialchars($s['name'])?></strong><div class="small text-secondary"><?=htmlspecialchars($s['name_hash'])?></div></td>
<td><?=htmlspecialchars($s['max_policy'])?></td>
<td><?=htmlspecialchars($s['audio_default'])?></td>
<td><?= $s['enabled'] ? '<span class="badge text-bg-success">ON</span>' : '<span class="badge text-bg-secondary">OFF</span>' ?></td>
<td>
<?php if ($s['enabled']): ?>
<a href="/stream.php?id=<?=$s['id']?>" class="btn btn-sm btn-outline-danger">Manage</a>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
</main>
</body></html>
