<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../src/bootstrap.php';
if (!isset($_SESSION['auth'])) { header('Location: /login.php'); exit; }

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$s = $id ? db()->prepare("SELECT * FROM streams WHERE id=?") : null;
if ($s) { $s->execute([$id]); $stream = $s->fetch(); } else { $stream = null; }

function sha1_5(string $name): string { return substr(sha1($name), 0, 5); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $mpd = trim($_POST['mpd_url'] ?? '');
    $audio = trim($_POST['audio_default'] ?? 'auto');
    $policy = trim($_POST['max_policy'] ?? 'auto');
    $kid = trim($_POST['key_id'] ?? '');
    $key = trim($_POST['key_value'] ?? '');
    $enabled = isset($_POST['enabled']);

    if ($name === '' || !filter_var($mpd, FILTER_VALIDATE_URL)) {
        $error = 'Stream name and a valid MPD URL are required.';
    } else {
        $hash = sha1_5($name);
        if ($id && $stream) {
            $q=db()->prepare("UPDATE streams SET name=?,name_hash=?,mpd_url=?,audio_default=?,max_policy=?,key_id=?,key_value=?,enabled=?,updated_at=NOW() WHERE id=?");
            $q->execute([$name,$hash,$mpd,$audio,$policy,$kid ?: null,$key ?: null,$enabled,$id]);
        } else {
            $q=db()->prepare("INSERT INTO streams(name,name_hash,mpd_url,audio_default,max_policy,key_id,key_value,enabled) VALUES(?,?,?,?,?,?,?,?)");
            $q->execute([$name,$hash,$mpd,$audio,$policy,$kid ?: null,$key ?: null,$enabled]);
            $id=(int)db()->lastInsertId();
        }
        header("Location: /stream.php?id=".$id); exit;
    }
}

if (!$stream && $id) { http_response_code(404); exit('Not found'); }
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $stream ? 'Edit' : 'Add' ?> Stream — MIUCAST</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>.btn-miu{background:#dc2626;color:#fff;border:0}.btn-miu:hover{background:#b91c1c;color:#fff}</style>
</head><body>
<main class="container py-4" style="max-width:900px">
<a href="/" class="text-decoration-none">← Streams</a>
<h2 class="mt-3"><?= $stream ? 'Edit Stream' : 'Add Stream' ?></h2>
<?php if(isset($error)): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" class="card shadow-sm border-0 mt-3"><div class="card-body p-4">
<div class="mb-3"><label class="form-label">Stream Name</label><input class="form-control" name="name" required value="<?=htmlspecialchars($stream['name'] ?? '')?>"></div>
<div class="mb-3"><label class="form-label">MPD URL</label><input class="form-control" type="url" name="mpd_url" required value="<?=htmlspecialchars($stream['mpd_url'] ?? '')?>"></div>
<div class="row g-3">
<div class="col-md-6"><label class="form-label">Audio Default</label><select class="form-select" name="audio_default">
<option value="auto">Auto (prefer THA/th)</option><option value="tha" <?=($stream['audio_default']??'')==='tha'?'selected':''?>>audio tha / th / THA</option>
</select></div>
<div class="col-md-6"><label class="form-label">Resolution Policy</label><select class="form-select" name="max_policy">
<option value="auto">Auto / highest</option><option value="l3_720p" <?=($stream['max_policy']??'')==='l3_720p'?'selected':''?>>L3 profile → max 720p</option><option value="720p" <?=($stream['max_policy']??'')==='720p'?'selected':''?>>Force 720p</option>
</select></div>
</div>
<hr class="my-4">
<h5>Authorized ClearKey (optional)</h5>
<p class="text-secondary small">Use only with content and keys you are authorized to decrypt. This passes ClearKey parameters to MediaFlow.</p>
<div class="row g-3">
<div class="col-md-6"><label class="form-label">KID / Key ID</label><input class="form-control" name="key_id" value="<?=htmlspecialchars($stream['key_id'] ?? '')?>"></div>
<div class="col-md-6"><label class="form-label">KEY</label><input class="form-control" name="key_value" value="<?=htmlspecialchars($stream['key_value'] ?? '')?>"></div>
</div>
<div class="form-check mt-4"><input class="form-check-input" type="checkbox" name="enabled" id="enabled" <?=(!$stream || $stream['enabled'])?'checked':''?>><label class="form-check-label" for="enabled">Enabled</label></div>
<button class="btn btn-miu mt-4"><?= $stream ? 'Save Changes' : 'Create Stream' ?></button>
</div></form>
<?php if($stream): ?>
<?php
$base=getenv('APP_BASE_URL') ?: 'http://127.0.0.1:2121';
$session=random_session_code();
$ttl=(int)(getenv('SESSION_TTL') ?: 21600);
$q=db()->prepare("INSERT INTO stream_sessions(stream_id,session_code,expires_at) VALUES(?,?,NOW()+(?||' seconds')::interval)");
$q->execute([$stream['id'],$session,$ttl]);
$url=rtrim($base,'/').'/live/'.$stream['name_hash'].'/'.$session.'.m3u8';
?>
<div class="alert alert-light border mt-4"><strong>Output URL</strong><div class="mt-2"><code><?=htmlspecialchars($url)?></code></div></div>
<?php endif; ?>
</main></body></html>
