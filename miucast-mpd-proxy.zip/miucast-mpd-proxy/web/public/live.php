<?php
declare(strict_types=1);
require_once __DIR__ . '/../src/bootstrap.php';

$path = $_SERVER['PATH_INFO'] ?? '';
if (!$path && isset($_SERVER['REQUEST_URI'])) $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (!preg_match('#^/live/([a-f0-9]{5})/([A-Za-z0-9]{4})\.m3u8$#', $path, $m)) {
    http_response_code(404); exit;
}
$hash=$m[1]; $session=$m[2];

$q=db()->prepare("SELECT s.*, ss.expires_at FROM streams s JOIN stream_sessions ss ON ss.stream_id=s.id WHERE s.name_hash=? AND ss.session_code=? AND s.enabled=TRUE AND ss.expires_at>NOW() LIMIT 1");
$q->execute([$hash,$session]);
$s=$q->fetch();
if (!$s) { http_response_code(403); exit('Invalid or expired session'); }

$profile = $_GET['profile'] ?? 'auto';
$maxRes = null;
if ($s['max_policy']==='720p' || ($s['max_policy']==='l3_720p' && strtolower($profile)==='l3')) $maxRes='720p';

$params = [
  'd'=>$s['mpd_url'],
  'api_password'=>getenv('MEDIAFLOW_API_PASSWORD')
];
if ($maxRes) $params['resolution']=$maxRes; else $params['max_res']='true';
if ($s['key_id'] && $s['key_value']) { $params['key_id']=$s['key_id']; $params['key']=$s['key_value']; }

$url=rtrim(getenv('MEDIAFLOW_URL'),'/').'/proxy/mpd/manifest.m3u8?'.http_build_query($params);

$ch=curl_init($url);
curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>30,CURLOPT_CONNECTTIMEOUT=>10]);
$body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
if ($body===false || $code>=400) { http_response_code($code>=400?$code:502); exit('Upstream MPD proxy error'); }

header('Content-Type: application/vnd.apple.mpegurl');
header('Cache-Control: no-store, no-cache, must-revalidate');
echo rewrite_mediaflow_manifest($body, $s['mpd_url'], $hash, $session);
