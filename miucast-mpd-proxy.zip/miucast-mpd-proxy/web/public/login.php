<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../src/bootstrap.php';

if (isset($_SESSION['auth'])) { header('Location: /'); exit; }
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['passcode'] ?? '');
    $expected = getenv('ADMIN_PASSCODE') ?: '1997';
    if (preg_match('/^\d{4}$/', $code) && hash_equals($expected, $code)) {
        session_regenerate_id(true);
        $_SESSION['auth'] = true;
        header('Location: /');
        exit;
    }
    $error = 'Invalid passcode';
}
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MIUCAST Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#fff}.login{max-width:380px;margin:12vh auto}.btn-miu{background:#dc2626;color:#fff}</style>
</head><body><main class="login">
<div class="text-center mb-4"><h2>MIUCAST</h2><div class="text-secondary">MPD PROXY</div></div>
<div class="card shadow-sm border-0"><div class="card-body p-4">
<?php if($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post">
<label class="form-label">4-digit Passcode</label>
<input class="form-control form-control-lg text-center mb-3" name="passcode" inputmode="numeric" maxlength="4" pattern="\d{4}" autofocus required>
<button class="btn btn-miu btn-lg w-100">LOGIN</button>
</form></div></div>
</main></body></html>
